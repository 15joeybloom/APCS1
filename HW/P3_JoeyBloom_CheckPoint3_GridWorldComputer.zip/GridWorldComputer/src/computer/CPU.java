package computer;

import info.gridworld.actor.Actor;

/**
 * @author Joey Bloom
 * 2013 Final Project
 * The CPU is responsible for sending and receiving Buses
 */
public class CPU extends Actor
{
    //bit masks
    protected static final short OPCODE =      -4096; //equivalent to unsigned 0xF000
    protected static final short ARG =    0x0FFF; //this can also be a numeric value
                                                      //as in the case of SET_ACCUMULATOR

    public static final short READ_TO_ACCUMULATOR = 0x0000;//address to read from
    public static final short WRITE_ACCUMULATOR =   0x4000;//address to write acc. to
    public static final short SET_ACCUMULATOR =     0x5000;//NUMERIC VALUE to load into acc.
    public static final short ADD_ACCUMULATOR =     0x6000;//address of addend
    public static final short SUBTRACT_ACCUMULATOR= 0x7000;//address of subtrahend
    public static final short JUMP =              /*0x8000*/-32768;//value of PC to set to
    public static final short BRANCH_IF_0 =       /*0x9000*/-28672;//memory location to
                                                                   //check for 0
}
