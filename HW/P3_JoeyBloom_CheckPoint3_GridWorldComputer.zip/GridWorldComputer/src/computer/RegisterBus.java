package computer;

import info.gridworld.grid.Location;

/**
 * @author Joey Bloom
 * 2013 Final Project
 * A RegisterBus is a Bus that visits one of the CPU's registers.
 */
public abstract class RegisterBus extends Bus
{
    /**
     * Memory addresses are 12 bits in this computer, however the least significant
     * bit of the PC will always be 0 because instructions are always stored
     * in even addresses because they are 2 bytes. Therefore only the 11 most
     * significant bits need to be stored.
     */
    public static final int PROGRAM_COUNTER_SIZE = 11;
    /**
     * this is used as temporary storage by the CPU. one byte.
     */
    public static final int ACCUMULATOR_SIZE = 8;

    public static final int START_ROW = -2;
        //the first register is in this row
    public static final int RETURN_COL = -12;
        //this is the column in which register buses turn south.
        //opposite of 1 more than largest register size.

    public static final short PROGRAM_COUNTER = 0;
    public static final short ACCUMULATOR = 1;

    /**
     * {@inheritDoc}
     */
    public RegisterBus(short a)
    {
        super(a);
        setDirection(Location.NORTH);
    }

    /**
     * {@inheritDoc}
     */
    public RegisterBus(short a, byte b)
    {
        super(a,b);
        setDirection(Location.NORTH);
    }

    @Override
    public void act()
    {
        Location loc = getLocation();
        int r = loc.getRow();
        int c = loc.getCol();
        int dir = getDirection();
        if(dir == Location.NORTH)
        {
            if(r - START_ROW + 1 > address)
            {
                move();
            }
            else
            {
                setDirection(Location.WEST);
            }
        }
        else if(dir == Location.WEST)
        {
            if(c <= RETURN_COL)
            {
                setDirection(Location.SOUTH);
            }
            else
            {
                Bit b = (Bit)getGrid().get(loc.getAdjacentLocation(Location.SOUTH));
                if(b != null)
                {
                    processBit(b,-c-1);
                }
                move();
            }
        }
        else if(dir == Location.SOUTH)
        {
            if(r == -1)
            {
                setDirection(Location.EAST);
            }
            else
            {
                move();
            }
        }
        else if(dir == Location.EAST)
        {
            move();
        }
        else
        {
            System.err.println("yer bus is on an angle bud");
        }
    }
}
