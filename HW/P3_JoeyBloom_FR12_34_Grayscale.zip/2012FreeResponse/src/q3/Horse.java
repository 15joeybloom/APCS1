package q3;

/**
 * @author Joey Bloom
 * 2012 Free Response Question 3
 *
 */
public interface Horse
{
    /** @return the horse's name */
    String getName();

    /** @return the horse's weight */
    int getWeight();
}
