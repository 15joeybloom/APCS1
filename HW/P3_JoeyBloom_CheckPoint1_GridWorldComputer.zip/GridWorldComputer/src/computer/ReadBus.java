package computer;

/**
 * @author 151bloomj
 */
public class ReadBus extends Bus
{
    public ReadBus(short a)
    {
        super(a);
    }

    @Override
    protected void processBit(Bit b, int p)
    {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
