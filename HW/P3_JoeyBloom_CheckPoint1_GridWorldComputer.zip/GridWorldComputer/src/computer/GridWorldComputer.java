package computer;

import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
import info.gridworld.grid.UnboundedGrid;

/**
 * @author Joey Bloom
 *
 */
public class GridWorldComputer
{

    public static void main(String[] args)
    {
        ActorWorld world = new ActorWorld(new UnboundedGrid());

        //set up memory
        for(int r = 0; r < Bus.MEMORY_R; r++)
        {
            for(int c = 0; c < 8 * Bus.MEMORY_C; c++)
            {
                world.add(new Location(2*r,(c+1) + c / 8 * 2), new Bit(false));
            }
        }

        world.add(new Location(-1,0),new WriteBus((short)0x0021,(byte)-86));
        world.show();
    }
}