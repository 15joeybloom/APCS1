package computer;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import java.awt.Color;

/**
 * @author Joey Bloom
 * 2013 Final Project
 *
 * The Bus is a sort of worker that communicates between CPU and memory.
 * It has a short representing its instruction. The short
 * contains the 12-bit memory address and a 4-bit instruction
 * of what to do at that address.
 *
 * This is the superclass for all
 */
public abstract class Bus extends Bug
{
    private final short address;
    protected byte dat;

    //bit masks
    private static final short TASK =      -0x8000; //equivalent to unsigned 0xF000
    private static final short ADDRESS =    0x0FFF;
    private static final short COL =        0x000F;
    private static final short ROW =        0x0FF0;

    public static final int MEMORY_C = 16;  //this way the first four bits of the address
                                            //are the column to visit
    public static final int MEMORY_R = (1 << 12) / MEMORY_C;
                                            //this way the middle 8 bits are the row
                                            //to visit

    /**
     * Constructs a Bus set to visit the specified memory address
     * @param a address to visit
     */
    public Bus(short a)
    {
        super();
        address = a;
        dat = 0;
        setDirection(Location.EAST);
        setColor(null);
    }

    /**
     * Constructs a Bus set to visit the specified memory address
     * with the specified byte to use at that address
     * @param a address to visit
     * @param b byte to use
     */
    public Bus(short a, byte b)
    {
        this(a);
        dat = b;
    }

    /**
     * Causes the Bus to step on its quest to visit memory and return to CPU
     * precondition: this Bus began at -1,0 facing Location.EAST and was
     * not modified except through the act method
     */
    @Override
    public final void act()
    {
        int direction = getDirection();
        Location loc = getLocation();
        int r = loc.getRow();
        int c = loc.getCol();
        if(direction == Location.EAST)
        {
            //if traversing correct memory location
            if(r > 0)
            {
                final int X = c % 10;
                if(X == 0)
                {
                    move();
                }
                else if(X == 9)
                {
                    setDirection(Location.NORTH);
                }
                else
                {
                    processBit(
                        (Bit)getGrid().get(loc.getAdjacentLocation(Location.NORTH)),
                        8-X);
                    move();
                }
            }
            //if has not reached correct col yet
            else if(c < (address & COL) * 10)
            {
                move();
            }
            else //if at correct col
            {
                setDirection(Location.SOUTH);
            }
        }
        else if(direction == Location.SOUTH)
        {
            //if not yet at correct row
            if(r < ((address & ROW) >>> 4) * 2 + 1)
            {
                move();
            }
            else //if at correct row
            {
                setDirection(Location.EAST);
            }
        }
        else if(direction == Location.NORTH)
        {
            //if not yet at row -1
            if(r > -1)
            {
                move();
            }
            else // if at row -1
            {
                setDirection(Location.WEST);
            }
        }
        else if(direction == Location.WEST)
        {
            move();
        }
        else
        {
            System.err.println("yer bus is on an angle bud");
        }
    }

    /**
     * This part of the Bus class is where the operation specific
     * to the subtype of Bus takes place.
     * @param b a reference to the Bit being visited
     * @param p the number of the bit being visited. 7 is the most significant
     *          bit or furthest left, 0 is the least significant or furthest right.
     */
    protected abstract void processBit(Bit b, int p);

    /**
     * Moves the bug forward
     */
    @Override
    public final void move()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null)
            return;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        if (gr.isValid(next))
            moveTo(next);
        else
            removeSelfFromGrid();
    }
}
