package q2;

/**
 * @author Joey Bloom
 * 2006 Free Response Question 2
 * An Item has a purchase price.
 */
public interface Item
{
    double purchasePrice();
}
