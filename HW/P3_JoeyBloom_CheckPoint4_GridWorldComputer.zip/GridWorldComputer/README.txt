Open the project in NetBeans and run the GridWorldComputer class. In Gridworld, click run.
Switch to full screen and/or scroll around to get a view of the whole computer.

For this checkpoint, I have set up a WriteProgramBus to write a brief meaningless
series of "instructions" to memory. This series of instructions can be observed
in the main method in the short[] passed to the WriteProgramBus in construction.
Click run to see how this Bus works.

Play with the different types of Buses to see how they work. Eventually the CPU
will control Buses to execute predetermined instructions, similar to assembly code.

When placing Buses, you need to place them at -1,0. Otherwise they
probably won't work right.

When constructing a Bus, you need to provide an address to visit. For MemoryBuses,
this is an address in memory, a short value of the form 0xRRC where RR is 8 bits
indicating the row to visit and C is 4 bits indicating the column. For example,
to visit the byte of memory whose most significant bit is at Location(-4,11),
one would construct a subclass of MemoryBus with the address 0x021 since it
is the second row and first column (all row and column counting begins at 0).
Addresses for RegisterBuses are simpler, simply provide the value of one of the
constants from the RegisterBus class (i.e. PROGRAM_COUNTER, ACCUMULATOR).

A note about the short field in Bus vs. CPU instructions:
These are different. The short field in Bus is the address
that the Bus is going to. For a MemoryBus, this is a location
in memory. For a RegisterBus, this is one of the constants
in RegisterBus (PROGRAM_COUNTER, ACCUMULATOR) indicating
which register to traverse to.
A CPU instruction is also a short. The 4 most significant bits are
the OPCODE indicating which operation is to be performed (see
the opcode constants in CPU). The next 12 bits are either a memory address or
a numeric value as specified by the particular opcode. If it is a
numeric value, only the 8 least significant bits will be used
because my memory only handles bytes.

SINCE THE LAST CHECKPOINT I wrote a few more Buses including the AddToAccumulatorBus
and SubtractFromAccumulatorBus. I made some minor changes to some subclasses of
RegisterBus to allow for the implementation of more registers, if I so desire
in the future. Mainly, I began work on the CPU. The CPU will be
able to function in two ways. It will be able to execute a predetermined "program"
of instructions, similar to how Java and other C-derived languages work.
It will also be able to execute individual instructions via the doInstruction(short)
method. This is similar to Lisp's REPL. Note that when using doInstruction,
the Buses are not visible as they act. Rest assured, they are indeed acting.

The CPU can be in two states. It can be executing a program (not halted) or
not executing a program (halted) ready to accept individual instructions. Calling
doProgram() starts the execution of a program and unhalts the CPU. When the program
reaches a HALT instruction, the CPU is halted and execution stops. Then
doInstruction() can be called to execute individual instructions.

At the moment the doProgram() method is incomplete. Don't use it yet. Just
use doInstruction() to execute one instruction at a time.

When writing instructions for doInstruction(), using hexadecimal is generally
easiest. Type "0x" preceding the number to indicate hexadecimal. The most
significant digit of the hexadecimal instruction should be the opcode. To see
the opcode constants, look in the CPU class. The three least significant
digits are then the argument (either an address or numeric value).