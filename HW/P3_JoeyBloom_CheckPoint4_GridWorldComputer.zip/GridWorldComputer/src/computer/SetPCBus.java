package computer;

/**
 * @author Joey Bloom
 * 2013 Final Project
 * Sets the Program Counter. Used in initializing the
 * CPU and jumping/branching.
 */
public class SetPCBus extends RegisterBus
{
    private short nextInstructionAddress;

    /**
     * Constructs a SetPCBus.
     * @param toSet memory address to set the PC to. Must be even.
     */
    public SetPCBus(short toSet)
    {
        super(PROGRAM_COUNTER);
        nextInstructionAddress = toSet;
    }

    /**
     * Sets the Bit to the corresponding Bit of the nextAddress
     * @param b
     * @param p
     */
    @Override
    protected void processBit(Bit b, int p)
    {
        b.set((nextInstructionAddress & (1 << ++p)) >>> p);
    }
}
