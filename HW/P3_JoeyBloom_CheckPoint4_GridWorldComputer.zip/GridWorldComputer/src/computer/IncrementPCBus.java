package computer;

/**
 * @author Joey Bloom
 * 2013 Final Project
 * Leaves the CPU, increments the Program Counter, and returns to the CPU
 * with the address of the next instruction. The address of this next instruction
 * can be accessed by the CPU via nextInstructionAddress().
 *
 * Image: PC++
 */
public class IncrementPCBus extends RegisterBus
{
    private boolean flipNext;
    private short nextInstructionAddress;

    /**
     * Constructs an IncrementPCBus set to visit the
     * Program Counter.
     */
    public IncrementPCBus()
    {
        super(PROGRAM_COUNTER);
        flipNext = true;
    }

    /**
     * {@inheritDoc }
     */
    @Override
    protected void processBit(Bit b, int p)
    {
        nextInstructionAddress |= b.getInt() << p;
        if(flipNext)
        {
            if(b.flip())//if after flipping b is 1, then do not flip the following bits
            {
                flipNext = false;
            }
        }
    }

    /**
     * Called by the CPU to get the address of the next instruction
     * @return a 12-bit value indicating a memory location.
     */
    public short getNextInstructionAddress()
    {
        return (short)(nextInstructionAddress << 1);
    }


}
