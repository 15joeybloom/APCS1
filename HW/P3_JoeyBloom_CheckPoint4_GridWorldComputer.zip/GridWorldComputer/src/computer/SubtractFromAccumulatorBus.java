package computer;

/**
 * @author Joey Bloom
 * 2013 Final Project
 * Adds its dat field to the accumulator. Does not
 * check for overflow.
 */
public class SubtractFromAccumulatorBus extends RegisterBus
{
    private boolean carry;

    /**
     * Constructs an AddAccumulatorBus to add the argument to
     * the accumulator.
     * @param b byte to add
     */
    public SubtractFromAccumulatorBus(byte b)
    {
        super(ACCUMULATOR, b);
        carry = false;
    }

    /**
     * Adds, to the argument Bit, the corresponding bit in the dat field as
     * indicated by the position argument. Adjusts the private carry field if
     * there should be a carry on the next bit.
     * @param b {@inheritDoc}
     * @param p {@inheritDoc}
     */
    @Override
    protected void processBit(Bit b, int p)
    {       
        //subtract carry from previous
        if(carry && !b.flip()) carry = false;        
        //subtract bit from dat
        if((dat & (1<<p)) != 0 && b.flip()) carry = true;        
    }
}
