package computer;

/**
 * @author Joey Bloom
 * 2013 Final Project
 * Retrieves the value of a register and returns to CPU.
 */
public class GetRegisterBus extends RegisterBus
{
    public GetRegisterBus(short a)
    {
        super(a);
    }

    /**
     * Reads a Bit of the accumulator and stores it in the Bus
     * @param b {@inheritDoc}
     * @param p {@inheritDoc}
     */
    @Override
    protected void processBit(Bit b, int p)
    {
        dat |= b.getInt() << p;
    }

    /**
     * Returns the accumulator
     * @return byte read from accumulator
     */
    public byte get()
    {
        return dat;
    }
}
