package computer;

import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

/**
 * @author Joey Bloom
 * 2013 Final Project
 * The CPU is responsible for sending and receiving Buses according to
 * instructions received from memory.
 *
 * image: brain
 */
public class CPU extends Actor
{
    //bit masks
    protected static final short OPCODE =      -4096; //equivalent to unsigned 0xF000
    protected static final short ARG =    0x0FFF; //this can also be a numeric value
                                                  //as in the case of SET_ACCUMULATOR

    //opcodes                                                    ARG INFORMATION
    public static final short READ_TO_ACCUMULATOR =     0x0000;//address to read from
    public static final short WRITE_FROM_ACCUMULATOR =  0x1000;//address to write acc. to
    public static final short SET_ACCUMULATOR =         0x2000;//NUMERIC VALUE to load into acc.
    public static final short ADD_ACCUMULATOR =         0x3000;//address of addend
    public static final short SUBTRACT_ACCUMULATOR=     0x4000;//address of subtrahend
    public static final short JUMP =                    0x5000;//value of PC to set to
    public static final short SKIP_NEXT_IF_0 =          0x6000;//memory location to check for 0
    public static final short HALT =                    0x7000;//arg doesn't matter

    private boolean halted = true;
    private ActorWorld world;

    /**
     * Constructs a CPU with a reference to the ActorWorld it
     * is contained in. The ActorWorld reference is only
     * held so the doInstruction method can add and call step.
     */
    public CPU(ActorWorld world)
    {
        this.world = world;
        setColor(null);
    }

    /**
     * Writes a program to memory with a short[] of instructions and
     * the desired initial value of the Program Counter. Begins
     * execution of the program.
     * @param instructions  instructions for this CPU to execute
     * @param pc            initial value of program counter
     */
    public void doProgram(short[] instructions, short pc)
    {
        halted = false;
        doInstruction((short)(JUMP | pc));
        new WriteProgramBus(pc, instructions).putSelfInGrid(getGrid(), getLocation().getAdjacentLocation(Location.SOUTH));
    }

    /**
     * Performs the specified instruction as if it was read from memory.
     * The method completes the instruction fully before returning. This
     * method will only execute the instruction if the CPU is halted; that is,
     * if it has run out of instructions from memory. Control Flow instructions
     * (SKIP_NEXT_IF_0, HALT) do nothing except for JUMP, which simply sets
     * the program counter.
     * @param instruction to execute
     */
    public void doInstruction(short instruction)
    {
        if(!halted) return;
        short arg = (short)(instruction & ARG);
        Location loc = getLocation();
        Location north = loc.getAdjacentLocation(Location.NORTH);
        Location south = loc.getAdjacentLocation(Location.SOUTH);
        switch(instruction & OPCODE)
        {
            case READ_TO_ACCUMULATOR:
                ReadBus reader =
                    new ReadBus(arg);
                putAndRun(reader,south,south);
                SetRegisterBus setter =
                    new SetRegisterBus(RegisterBus.ACCUMULATOR, reader.get());
                putAndRun(setter,north,south);
                break;
            case WRITE_FROM_ACCUMULATOR:
                GetRegisterBus getter =
                    new GetRegisterBus(RegisterBus.ACCUMULATOR);
                putAndRun(getter,north,south);
                WriteBus writer =
                    new WriteBus(arg,getter.get());
                putAndRun(writer,south,south);
                break;
            case SET_ACCUMULATOR:
                setter =
                    new SetRegisterBus(RegisterBus.ACCUMULATOR, (byte)arg);
                putAndRun(setter,north,south);
                break;
            case ADD_ACCUMULATOR:
                reader =
                    new ReadBus(arg);
                putAndRun(reader,south,south);
                AddToAccumulatorBus adder=
                    new AddToAccumulatorBus(reader.get());
                putAndRun(adder,north,south);
                break;
            case SUBTRACT_ACCUMULATOR:
                reader =
                    new ReadBus(arg);
                putAndRun(reader,south,south);
                SubtractFromAccumulatorBus subtracter =
                    new SubtractFromAccumulatorBus(reader.get());
                putAndRun(subtracter,north,south);
                break;
            case JUMP:
                SetPCBus setterPC =
                    new SetPCBus(arg);
                putAndRun(setterPC,north,south);
                break;
        }
    }
    /**
     * Adds the Bus to the same ActorWorld as this CPU
     * at the specified init Location and steps the ActorWorld
     * until it returns to the specified fin Location. Bus
     * is removed from grid.
     * @param b Bus to putAndRun
     * @param init Location to put
     * @param fin Location to stop acting at.
     */
    private void putAndRun(Bus b, Location init, Location fin)
    {
        world.add(init,b);
        b.act();//this extra act() prevents the Bus from being removed when it
                //turns in place on the first step.
        do
        {
            b.act();
        }while(!b.getLocation().equals(fin));
        b.removeSelfFromGrid();
    }

    /**
     * Steps in the execution of the program. Does nothing
     * if the CPU is halted.
     */
    @Override
    public void act()
    {
        if(halted) return;
    }
}
