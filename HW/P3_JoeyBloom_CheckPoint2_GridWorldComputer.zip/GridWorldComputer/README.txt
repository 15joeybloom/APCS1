Open the project in NetBeans and run the GridWorldComputer class. In Gridworld, click run.
Switch to full screen and/or scroll around to get a view of the whole computer.

Play with the different types of Buses to see how they work. Eventually the CPU
will control Buses to execute predetermined instructions, similar to assembly code.

When constructing a Bus, you need to provide an address to visit. For MemoryBuses,
this is an address in memory, a short value of the form 0xRRC where RR is 8 bits
indicating the row to visit and C is 4 bits indicating the column. For example,
to visit the byte of memory whose most significant bit is at Location(-4,11),
one would construct a subclass of MemoryBus with the address 0x021 since it
is the second row and first column (all row and column counting begins at 0).
Addresses for RegisterBuses are simpler, simply provide the value of one of the
constants from the RegisterBus class (i.e. PROGRAM_COUNTER, ACCUMULATOR).

Since the last checkpoint, I divided Buses into RegisterBuses and MemoryBuses, I
built the registers, and I wrote IncrementPCBus and FetchInstructionBus.