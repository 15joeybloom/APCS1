package computer;

/**
 * @author 151bloomj
 */
public class ReadBus extends MemoryBus
{
    public ReadBus(short a)
    {
        super(a);
    }

    @Override
    protected void processBit(Bit b, int p)
    {
        dat |= b.getInt() << p;
    }

    /**
     * Returns the byte read by this ReadBus
     * @return byte read from address
     */
    public byte get()
    {
        return dat;
    }
}
