package computer;

import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Location;
import info.gridworld.grid.UnboundedGrid;
import java.io.File;

/**
 * @author Joey Bloom
 *
 */
public class GridWorldComputer
{
    public static void main(String[] args) throws ClassNotFoundException
    {
        ActorWorld world = new ActorWorld(new UnboundedGrid<Actor>());

        //this loads all Actors into gridworld so you can play with them.
        //they are then removed later so they don't destroy the memory Bits
        //and register Bits
        Bus[] bs = new Bus[]{
            new IncrementPCBus(),
            new FetchInstructionBus((short)0),
            new ReadBus((short)0),
            new WriteBus((short)0,(byte)0),
        };
        for(int i = 0; i < bs.length; i++)
        {
            world.add(new Location(-5,5+i),bs[i]);
        }


        //set up memory
        for(int r = 0; r < MemoryBus.MEMORY_R; r++)
        {
            for(int c = 0; c < 8 * MemoryBus.MEMORY_C; c++)
            {
                world.add(new Location(2*r,(c+1) + c / 8 * 2), new Bit(false));
            }
        }

        //set up registers
        //set up program counter
        for(int i = 0; i < RegisterBus.PROGRAM_COUNTER_SIZE; i++)
        {
            world.add(new Location(-2*RegisterBus.PROGRAM_COUNTER + RegisterBus.START_ROW, -i - 1), new Bit(false));
        }
        //set up accumulator
        for(int i = 0; i < RegisterBus.ACCUMULATOR_SIZE; i++)
        {
            world.add(new Location(-2*RegisterBus.ACCUMULATOR + RegisterBus.START_ROW, -i - 1), new Bit(false));
        }

        world.show();

        //removes the Buses created earlier
        for(Bus b : bs)
        {
            b.removeSelfFromGrid();
        }
    }
}