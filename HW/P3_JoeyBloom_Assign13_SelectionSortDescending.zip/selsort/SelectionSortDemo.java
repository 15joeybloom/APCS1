import java.util.Arrays;

/**
   @author Joey Bloom
   Assignment #13
   This program demonstrates the selection sort algorithm by
   sorting an array that is filled with random numbers.
*/
public class SelectionSortDemo
{  
   static int i = 0;
   public static void main(String[] args)
   {  
      int[] a = ArrayUtil.randomIntArray(20, 100);
      System.out.println(Arrays.toString(a));

      SelectionSorter sorter = new SelectionSorter(a);
      sorter.sort();

      System.out.println(Arrays.toString(a));
      
      i++;
      if(i < 3)
      {
         main(args);    
      }
   }
}
/*
Output:
[89, 85, 28, 8, 80, 85, 47, 78, 74, 15, 12, 29, 30, 70, 76, 27, 51, 0, 6, 79]
[89, 85, 85, 80, 79, 78, 76, 74, 70, 51, 47, 30, 29, 28, 27, 15, 12, 8, 6, 0]
[81, 32, 47, 71, 9, 63, 20, 30, 57, 39, 11, 48, 79, 59, 24, 17, 12, 15, 34, 65]
[81, 79, 71, 65, 63, 59, 57, 48, 47, 39, 34, 32, 30, 24, 20, 17, 15, 12, 11, 9]
[48, 8, 87, 59, 16, 15, 44, 9, 99, 87, 34, 77, 83, 42, 19, 6, 22, 54, 2, 88]
[99, 88, 87, 87, 83, 77, 59, 54, 48, 44, 42, 34, 22, 19, 16, 15, 9, 8, 6, 2]

 */

   
