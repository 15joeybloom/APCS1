/**
 * @author Joey Bloom
 * Assignment #14
 * Tests the SelectionSorterCoinsTester class
 */
public class SelectionSorterCoinsTester
{
    public static void main(String[] args)
    {
        Coin[] coins1 = new Coin[]
        {
            new Coin(.25,"Quarter"),
            new Coin(.05,"Nickel"),
            new Coin(.10,"Dime"),
            new Coin(.01,"Penny"),
            new Coin(.05,"Nickel")
        };
        
        Coin[] coins2 = new Coin[]
        {
            new Coin(.25,"Quarter")
        };
        
        Coin[] coins3 = new Coin[0];
        
        SelectionSorterCoins sorter = new SelectionSorterCoins(coins1);
        System.out.println(sorter);
        sorter.sort();
        System.out.println(sorter);
        System.out.println();
        
        sorter = new SelectionSorterCoins(coins2);
        System.out.println(sorter);
        sorter.sort();
        System.out.println(sorter);
        System.out.println();
        
        sorter = new SelectionSorterCoins(coins3);
        System.out.println(sorter);
        sorter.sort();
        System.out.println(sorter);
        System.out.println();
    }
}

/*
Output:
Quarter is worth $0.25
Nickel is worth $0.05
Dime is worth $0.1
Penny is worth $0.01
Nickel is worth $0.05

Penny is worth $0.01
Nickel is worth $0.05
Nickel is worth $0.05
Dime is worth $0.1
Quarter is worth $0.25


Quarter is worth $0.25

Quarter is worth $0.25






 */
