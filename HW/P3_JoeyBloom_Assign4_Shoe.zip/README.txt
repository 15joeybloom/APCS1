Please completely disregard P3_JoeyBloom_Assign3_Shoe
The Deck and Shoe classes contained herein are correct