package blackjack;

import javax.swing.JApplet;

/**
 * @author Joey Bloom
 *
 */
public class BlackjackApplet extends JApplet
{

    /**
     * Initialization method that will be called after the applet is loaded
     * into the browser.
     */
    @Override
    public void init()
    {
        // TODO start asynchronous download of heavy resources
    }
    // TODO overwrite start(), stop() and destroy() methods
}
