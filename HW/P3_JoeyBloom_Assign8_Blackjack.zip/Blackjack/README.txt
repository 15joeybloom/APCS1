Joey Bloom
Blackjack
2/20/13
To start the project, open the project folder in 
NetBeans and click the green Run Project button.
Javadocs are in the dist folder.

Highlights:
    User-friendly GUI displays images of the Cards in the Player and Dealer Hands.
When the outcome of the hand is determined, the round is stopped, without unnecessary
gameplay. The user may Save and Load his progress, stored as files locally. The Dealer
is named after some randomly selected member of my APCS class. The player's bet and
balance are displayed as a pile of chips. I think I deserve an A. I was rather lazy with
screenshots, but I did go above and beyond by implementing a GUI with saving, loading,
random Dealer names, and chips. I learned quite a bit about the importance of planning.
I didn't do much planning for my GUI beyond a simple drawing, and I paid the price with
time.

Known Bugs:
    The dealer cannot have more than 6 cards in his hand.
    The balance and bet will not display if the amount is greater than 5 digits.
    both dealer and player blackjack does not handle correctly.