/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack;

/**
 * @author 151bloomj
 * Assignment #2
 * Tests Card
 */
public class CardTester 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Card threeHearts = new Card(3,2);
        Card alsoThreeHearts = new Card(threeHearts);
        System.out.println(threeHearts + " " + alsoThreeHearts);
        System.out.println(threeHearts.getValue());
        
        Card ace = new Card(0,0);
        System.out.println(ace + " " + ace.getValue());
        ace.hardenAce();
        System.out.println("Hardened: " + ace + " " + ace.getValue());
    }
}
