package blackjack;

import java.util.ArrayList;
import java.util.Random;

/**
 * @author 151bloomj
 * Assignment #3
 * A Shoe has multiple decks of Cards
 */
public class Shoe
{
    private ArrayList<Card> cards = new ArrayList<Card>();
    private int numDecks;
    
    /**
     * Constructs an empty Shoe
     */
    public Shoe()
    {
        numDecks = 0;
    }
    
    /**
     * Constructs a Shoe
     * @param n number of decks
     */
    public Shoe(int n)
    {
        this();
        addDecks(n);
        numDecks = n;
    }
    
    /**
     * Adds a deck to the Shoe
     */
    private void addDecks(int n)
    {
        for(int i = 0; i < n; i++)
        {
            for(int s = 0; s < 4; s++)
            {
                cards.add(new Card(0,s));
                for(int r = 2; r <= 13; r++)
                {
                    cards.add(new Card(r,s));
                }
            }
        }
    }
    
    /**
     * Shuffles the Shoe
     */
    public void shuffle()
    {
        Random rand = new Random();
        ArrayList<Card> shuffledShoe = new ArrayList<Card>();
        while(!cards.isEmpty())
        {
            shuffledShoe.add(cards.remove(rand.nextInt(cards.size())));
        }
        cards = shuffledShoe;
    }
    
    /**
     * Returns a String showing all the cards in the Shoe, in order starting
     * at the bottom of the Shoe. The last Card is the top Card.
     */
    @Override
    public String toString()
    {
        String returnMe = "";
        for(Card c : cards)
        {
            returnMe += c + " ";
        }
        return returnMe;
    }
    
    /**
     * Takes a Card off the top of the Shoe. The Card is removed from the Shoe
     * @return Card at the top of the Shoe
     */
    public Card takeCardOffTop()
    {
        return cards.remove(cards.size()-1);
    }
    
    /**
     * Get a Card from the Shoe. The Card is not removed from the Shoe.
     * @param n position in deck to get Card from. 0 is the bottom, this.size() - 1 is the top.
     * @return Card at position n
     */
    public Card get(int n)
    {
        return cards.get(n);
    }
    
    /**
     * returns the number of cards in the Shoe
     * @return size
     */
    public int size()
    {
        return cards.size();
    }
}